from pathlib import Path
import sqlite3

def test_schema_present():
    text=Path('app.py').read_text()
    for table in ['users','people','partners','documents','incidents','reviews','audit_log']:
        assert f'CREATE TABLE IF NOT EXISTS {table}' in text
